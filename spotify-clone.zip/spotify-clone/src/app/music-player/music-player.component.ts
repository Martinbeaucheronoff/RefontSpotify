import { Component, Input, ViewChild, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-music-player',
  templateUrl: './music-player.component.html',
  styleUrls: ['./music-player.component.css'],
  standalone: true,
  imports: [CommonModule],
})
export class MusicPlayerComponent implements OnChanges {
  @Input() currentSong: any;
  @ViewChild('audio', { static: false }) audioRef!: ElementRef<HTMLAudioElement>;

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
    if (changes['currentSong'] && this.currentSong) {
      setTimeout(() => this.playCurrentSong(), 0); // Ajout d'un délai pour garantir que l'élément audio est bien initialisé
    }
  }

  playCurrentSong() {
    const audioElement = this.audioRef?.nativeElement;
    if (!audioElement) {
      console.error('Audio element not found');
      return;
    }

    audioElement.src = this.currentSong.url;
    audioElement.load();

    audioElement
      .play()
      .then(() => console.log(`Playing: ${this.currentSong.title}`))
      .catch((err) => console.error('Playback error:', err));
  }
}

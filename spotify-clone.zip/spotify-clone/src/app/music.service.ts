import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MusicService {
  private musicLibrary = [
    { id: 1, title: 'Reflet', artist: 'Mwa', url: 'assets/music/Reflet.mp3' },
    { id: 2, title: 'Ma Meilleur Ennemie', artist: 'Stromae, Pomme', url: 'assets/music/Ma Meilleure Ennemie-Stromae.mp3' },
  ];

  getMusicLibrary() {
    return this.musicLibrary;
  }
}

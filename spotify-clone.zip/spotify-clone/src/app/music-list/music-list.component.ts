import { Component, EventEmitter, Output } from '@angular/core';
import { MusicService } from '../music.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-music-list',
  templateUrl: './music-list.component.html',
  styleUrls: ['./music-list.component.css'],
  standalone: true,
  imports: [CommonModule],
})
export class MusicListComponent {
  @Output() songSelected = new EventEmitter<any>();
  musicLibrary: any[];
  selectedSongId: number | null = null;

  constructor(private musicService: MusicService) {
    this.musicLibrary = this.musicService.getMusicLibrary();
  }

  onSelect(song: any) {
    if (this.selectedSongId === song.id) {
      this.songSelected.emit(null); // Réinitialisation
      setTimeout(() => this.songSelected.emit(song), 0);
    } else {
      this.selectedSongId = song.id;
      this.songSelected.emit(song);
    }
  }
}
